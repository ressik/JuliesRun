-- phpMyAdmin SQL Dump
-- version 2.8.0.1
-- http://www.phpmyadmin.net
-- 
-- Host: custsql-ipw22.eigbox.net
-- Generation Time: May 08, 2012 at 10:26 PM
-- Server version: 5.0.91
-- PHP Version: 4.4.9
-- 
-- Database: `royal_race`
-- 
CREATE DATABASE `royal_race` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `royal_race`;

-- --------------------------------------------------------

-- 
-- Table structure for table `users`
-- 

CREATE TABLE `users` (
  `firstName` varchar(254) default NULL,
  `lastName` varchar(254) default NULL,
  `email` varchar(254) default NULL,
  `paid` varchar(254) default NULL,
  `race` varchar(254) default NULL,
  `rank` varchar(256) default NULL,
  `id` int(254) NOT NULL auto_increment,
  `shirtSize` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=53 DEFAULT CHARSET=latin1 AUTO_INCREMENT=53 ;

-- 
-- Dumping data for table `users`
-- 

INSERT INTO `users` VALUES ('Sue', 'Mallory', 'sue@tinomen.com', '1', '5k', '30-39', 17, NULL);
INSERT INTO `users` VALUES ('Macie', 'Wilhelm', 'ressik@gmail.com', '1', '1k', 'Under 12', 16, 'Child Small');
INSERT INTO `users` VALUES ('Tiffany', 'Wilhelm', 'tiffanyanna@gmail.com', '1', '5k', '20-29', 15, 'Medium');
INSERT INTO `users` VALUES ('Paul', 'Wilhelm', 'ressik@gmail.com', '1', '5k', '30-39', 14, 'X-Large');
INSERT INTO `users` VALUES ('Susan', 'Wilhelm', 'wilhelmss@comcast.net', '1', '5k', '50-65', 11, 'X-Large');
INSERT INTO `users` VALUES ('Kelsey', 'Allen', 'kelseyallen01@gmail.com', '1', '5k', '20-29', 28, 'Medium');
INSERT INTO `users` VALUES ('Lynne', 'Warren', 'lynnwarren@q.com', '0', '5k', '50-65', 29, 'Medium');
INSERT INTO `users` VALUES ('Tiffany', 'Zaugg', 'tiffanyzaugg@gmail.com', '1', '5k', '30-39', 30, 'Large');
INSERT INTO `users` VALUES ('Mindy', 'Green', 'Luvbg345@hotmail.com', '0', '5k', 'Under 12', 31, 'X-Small');
INSERT INTO `users` VALUES ('Melanie', 'Kramer', 'angelakramer@comcast.net', '1', '1k', 'Under 12', 32, 'Child Small');
INSERT INTO `users` VALUES ('Angela', 'Kramer', 'angelakramer@comcast.net', '1', '5k', '30-39', 33, 'X-Large');
INSERT INTO `users` VALUES ('Mark', 'Kramer', 'moxnix2@gmail.com', '1', '5k', '50-65', 34, 'XX-Large');
INSERT INTO `users` VALUES ('Austin', 'Marsh', 'lisa.p.marsh@gmail.com', '0', '1k', 'Under 12', 42, 'Child Medium');
INSERT INTO `users` VALUES ('Megan', 'Marsh', 'lisa.p.marsh@gmail.com', '0', '1k', 'Under 12', 43, 'Child Medium');
INSERT INTO `users` VALUES ('Matthew', 'Upton', 'matthew.upton@utah.edu', '0', '5k', '30-39', 41, 'XX-Large');
INSERT INTO `users` VALUES ('Joseph', 'Saxton', 'erisaxton@hotmail.com', '0', '1k', 'Under 12', 38, 'Child Medium');
INSERT INTO `users` VALUES ('Allie', 'Saxton', 'erisaxton@hotmail.com', '0', '1k', 'Under 12', 39, 'Child Medium');
INSERT INTO `users` VALUES ('dd', 'dd', 'adf@adf.com', '0', '5k', 'Under 12', 44, 'Child Small');
INSERT INTO `users` VALUES ('Tim', 'Burton', 'jburton@itt-tech.edu', '0', '5k', '30-39', 45, 'XX-Large');
INSERT INTO `users` VALUES ('Jackson', 'Ericksen', 'jennyandjackson@yahoo.com', '1', '1k', 'Under 12', 46, 'Child Medium');
INSERT INTO `users` VALUES ('Cindy', 'Irvine', '', '0', '5k', '30-39', 47, 'XX-Large');
INSERT INTO `users` VALUES ('Cindy', 'Irvine', '', '0', '5k', '30-39', 48, 'XX-Large');
INSERT INTO `users` VALUES ('Robert', 'Stone', 'robertraystone@yahoo.com', '0', '5k', '40-49', 49, 'X-Large');
INSERT INTO `users` VALUES ('Katie', 'Stone', 'robertraystone@yahoo.com', '0', '5k', '12-19', 50, 'X-Large');
INSERT INTO `users` VALUES ('Barbara', 'Harper', 'Bharp62@yahoo.com', '0', '5k', 'Under 12', 51, 'Child Small');
INSERT INTO `users` VALUES ('Barbara', 'Harper', 'Bharp62@yahoo.com', '0', '5k', 'Under 12', 52, 'Child Small');
